package teamcode;



import virtual_robot.controller.LinearOpMode;

import static java.lang.Math.*;
import static teamcode.MathFunctions.*;


/**
 * Example OpMode. Demonstrates use of gyro, color sensor, encoders, and telemetry.
 *
 */
public class TimeDriveTest extends LinearOpMode {
    private Hardware robot = new Hardware();
    private TimeTest times = new TimeTest();
    private Point target = new Point(50,100);
    private double distanceToTarget = 40;
    public void runOpMode(){
        robot.init(hardwareMap);
        telemetry.addData("finish","wating to start");
        telemetry.update();
        System.out.println("init");
        
        waitForStart();
        while (opModeIsActive() && distanceToTarget > 10){


            double angleToTarget = Math.toDegrees(Math.atan2(target.y - bot.getPoint().y,target.x - bot.getPoint().x)) - robot.GetGyroAngle();
            angleToTarget = MathFunctions.RotateAngle(angleToTarget,90);
            distanceToTarget = abs(MathFunctions.dist2D(target,new Point(bot.getPoint().x , bot.getPoint().y)));
            double timeToTravle = (distanceToTarget/10) * times.timeToDrive;
            double timeToTurn   =  ((1/(360/angleToTarget))) * times.timeToRotate;


            double steer = (((1/(times.timeToRotate/timeToTurn))) / abs((1/(times.timeToRotate/timeToTurn)))) - ((1/(times.timeToRotate/timeToTurn)));
            double speed = range(((1/(times.timeToDrive/timeToTravle))),1,-1);
            telemetry.addData("time to rotate - " , timeToTurn);
            telemetry.addData("time to Drive - " , timeToTravle);

            telemetry.addData(" ---------- "," ---------- ");

            telemetry.addData("angle to target - " , angleToTarget);
            telemetry.addData("distance to target - " , distanceToTarget);

            telemetry.addData(" ---------- "," ---------- ");

            telemetry.addData("steer - " , steer);
            telemetry.addData("speed" , speed);

            double leftSpeed = speed;
            double rightSpeed = speed;

            if(angleToTarget > 2) {
                leftSpeed  += steer;
                rightSpeed -= steer;
            }else if(angleToTarget < -2){
                leftSpeed  -= steer;
                rightSpeed += steer;
            }

            // Normalize speeds if either one exceeds +/- 1.0;

            robot.setDriveMotorsPower(leftSpeed, Hardware.DRIVE_MOTOR_TYPES.LEFT);
            robot.setDriveMotorsPower(rightSpeed, Hardware.DRIVE_MOTOR_TYPES.RIGHT);


            telemetry.update();

        }

    }
}
