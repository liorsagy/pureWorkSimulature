/* Copyright (c) 2017 FIRST. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided that
 * the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list
 * of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice, this
 * list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.
 *
 * Neither the name of FIRST nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
 * LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package teamcode;

import virtual_robot.hardware.DcMotor;
import virtual_robot.hardware.HardwareMap;
import virtual_robot.hardware.bno055.BNO055IMU;
import virtual_robot.util.navigation.AngleUnit;
import virtual_robot.util.navigation.AxesOrder;
import virtual_robot.util.navigation.AxesReference;
import virtual_robot.util.navigation.Orientation;
import virtual_robot.util.time.ElapsedTime;

/**
 * This is NOT an opmode.
 *
 * This class can be used to define all the specific hardware for a single robot.
 * In this case that robot is a Pushbot.
 * See PushbotTeleopTank_Iterative and others classes starting with "Pushbot" for usage examples.
 *
 * This hardware class assumes the following device names have been configured on the robot:
 * Note:  All names are lower case and some have single spaces between words.
 *
 * Motor channel:  Left  drive motor:        "left_drive"
 * Motor channel:  Right drive motor:        "right_drive"
 * Motor channel:  Manipulator drive motor:  "left_arm"
 * Servo channel:  Servo to open left claw:  "left_hand"
 * Servo channel:  Servo to open right claw: "right_hand"
 */
public class Hardware {
    public Point position = new Point(0,0);
    /* Public OpMode members. */
    Point reset = new Point(0,0);

    DcMotor driveLeftBack = null;
    DcMotor driveRightBack = null;
    DcMotor driveLeftFront = null;
    DcMotor driveRightFront = null;
    double DriveY;
    double DriveX;

    BNO055IMU imu;

    public Point point() {
        return new Point(getX(),getY());
    }

    public double GetGyroAngle() {
        Orientation orientation = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.RADIANS);
        return (Math.toDegrees(orientation.firstAngle)) + 180;
    }

    public void moveX(double v) {
        double a = 0;//GetGyroAngle();

        a+=135;

        DriveY += v * Math.sin(MathFunctions.AngleWrap(Math.toRadians(-a)));
        DriveX += v * Math.cos(MathFunctions.AngleWrap(Math.toRadians(-a)));
    }

    public void moveY(double v) {
        double a = GetGyroAngle();

        a+=45;

        DriveY += v * Math.sin(MathFunctions.AngleWrap(Math.toRadians(a)));
        DriveX += v * Math.cos(MathFunctions.AngleWrap(Math.toRadians(a)));
    }
    public void move(double x,double y,double t){
        double a = 180-GetGyroAngle();
        double v = Math.hypot(x,y);
        a+=45;
        a +=90+Math.toDegrees(Math.atan2(y,x));
        DriveY = v * Math.sin((Math.toRadians(a)));
        DriveX = v * Math.cos((Math.toRadians(a)));
        driveLeftBack.setPower(-DriveY-t);
        driveRightBack.setPower(-DriveX+t);
        driveLeftFront.setPower(-DriveX-t);
        driveRightFront.setPower(-DriveY+t);


    }


    //Declaration of the drive motor types.
    public enum DRIVE_MOTOR_TYPES {
        LEFT,
        RIGHT,
        SIDE_WAYS,
        DIAGONAL_RIGHT,
        DIAGONAL_LEFT,
        ALL
    }


    /* local OpMode members. */
    HardwareMap hwMap =  null;

    /* Constructor */
    public Hardware(){

    }


    /* Initialize standard Hardware interfaces */
    public void init(HardwareMap ahwMap) {
        hwMap = ahwMap;

        imu = hwMap.get(BNO055IMU.class, "imu");


        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        parameters.accelerationIntegrationAlgorithm = null;
        parameters.accelUnit = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        parameters.angleUnit = BNO055IMU.AngleUnit.DEGREES;
        parameters.calibrationData = null;
        parameters.calibrationDataFile = "";
        parameters.loggingEnabled = false;
        parameters.loggingTag = "Who cares.";

        imu.initialize(parameters);


        // Define and Initialize Motors
        driveLeftBack = hwMap.get(DcMotor.class, "back_left_motor");
        driveRightBack = hwMap.get(DcMotor.class, "back_right_motor");
        driveRightFront = hwMap.get(DcMotor.class, "front_right_motor");
        driveLeftFront = hwMap.get(DcMotor.class, "front_left_motor");



        driveLeftBack.setDirection(DcMotor.Direction.REVERSE);
        driveLeftFront.setDirection(DcMotor.Direction.REVERSE);

        driveRightBack.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        driveLeftBack.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        driveRightFront.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        driveRightBack.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        driveLeftBack.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        driveLeftFront.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        reset.x = getX();
        reset.y = getY();


    }


    public void setDriveMotorsPower(double power, DRIVE_MOTOR_TYPES driverMotorType){
        switch (driverMotorType){
            case LEFT:
                driveLeftFront.setPower(power);
                driveLeftBack.setPower(power);
                break;
            case RIGHT:
                driveRightFront.setPower(power);
                driveRightBack.setPower(power);
                break;
            case SIDE_WAYS:
                driveLeftBack.setPower(-power);
                driveLeftFront.setPower(power);
                driveRightBack.setPower(power);
                driveRightFront.setPower(-power);
                break;
            case DIAGONAL_LEFT:
                driveRightFront.setPower(power);
                driveLeftBack.setPower(power);
                break;
            case DIAGONAL_RIGHT:
               driveLeftFront.setPower(power);
               driveRightBack.setPower(power);
                break;

            case ALL:
            default:
                driveLeftFront.setPower(power);
                driveLeftBack.setPower(power);
                driveRightFront.setPower(power);
                driveRightBack.setPower(power);
                break;
        }
    }

    public double getX(){
        return driveLeftBack.getCurrentPosition() - reset.x;
    }

    public double getY(){
        return driveRightBack.getCurrentPosition() - reset.y;
    }

 }

