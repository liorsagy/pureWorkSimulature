package teamcode;


import static java.lang.Math.abs;
import static teamcode.MathFunctions.dist2D;

import virtual_robot.controller.LinearOpMode;

import java.util.ArrayList;


/**
 * Example OpMode. Demonstrates use of gyro, color sensor, encoders, and telemetry.
 *
 */
public class Test extends LinearOpMode {
    RobotMovement robotMovement = new RobotMovement();
    ArrayList<CurvePoint> path = new ArrayList();
    public void runOpMode(){
        robotMovement.robot.init(hardwareMap);
        path.add(new CurvePoint(0,0,1.0,0.5,10,0,1.0));
        path.add(new CurvePoint(100,100,0.2,0.5,25,0,1.0));
        path.add(new CurvePoint(120,150,0.2,0.5,15,0,1.0));

        path.add(new CurvePoint(100,100,0.2,0.5,15,0,1.0));

//        //path.add(new CurvePoint(286,-200,1.0,0.5,10,0,1.0));
        //path.add(new CurvePoint(200,200,1.0,0.5,50,Math.toRadians(30),1.0));
        telemetry.addData("finish","wating to start");
        telemetry.update();
        waitForStart();
        do {

            telemetry.addData("opMose", "is active");
            telemetry.addData("bot point", robotMovement.BotPoint());

            telemetry.addData("error", robotMovement.error);
            telemetry.addData("steer", robotMovement.steer);
            robotMovement.followCurve(path, 1);
            sleep(30);
          //  sleep(50);
            telemetry.addData("DISTANCE : ", dist2D(robotMovement.followMe,robotMovement.BotPoint()));
            //robotMovement.robot.setDriveMotorsPower(0, Hardware.DRIVE_MOTOR_TYPES.ALL);
            //sleep(250);

            // telemetry.addData("followMe:", "X => " + robotMovement.followMe.x + " Y => " + robotMovement.followMe.y);
            telemetry.update();
        }while (opModeIsActive());
        while (opModeIsActive()){
            robotMovement.robot.setDriveMotorsPower(0, Hardware.DRIVE_MOTOR_TYPES.ALL);

            telemetry.addData("DISTANCE : ", dist2D(robotMovement.followMe,robotMovement.BotPoint()));
            telemetry.addData("bot point", robotMovement.BotPoint());

            telemetry.addData("error",robotMovement.error);
            telemetry.addData("steer", robotMovement.steer);
            telemetry.update();
        }
       /* waitForStart();
        while (opModeIsActive()){
            robotMovement.gotoPosition(new Point(100,100),1,30,0.2);
            //robotMovement.robot.setDriveMotorsPower(-1, Hardware.DRIVE_MOTOR_TYPES.DIAGONAL_RIGHT);
            angaleOfmovement();

            telemetry.addData("Y : " , robotMovement.BotPoint());
            telemetry.addData("A : " , robotMovement.robot.GetGyroAngle());
            telemetry.update();
        }*/
    }
    public void angaleOfmovement(){
        Point P = robotMovement.BotPoint();
        sleep(50);
        Point C = robotMovement.BotPoint();
        double a = Math.toDegrees(Math.atan2(C.y-P.y,C.x-P.x));
        telemetry.addData("angle : ",a);

    }
}
