package teamcode;



import virtual_robot.controller.LinearOpMode;
import virtual_robot.util.time.ElapsedTime;


/**
 * Example OpMode. Demonstrates use of gyro, color sensor, encoders, and telemetry.
 *
 */
public class TimeTest extends LinearOpMode {
    private Hardware robot = new Hardware();
    private ElapsedTime time = new ElapsedTime();
    private int rotations = 0;
    private int traveld = 0;

    double timeToRotate = 4.510396766666667;
    double timeToDrive = 0.08227949;
    public void runOpMode(){
        robot.init(hardwareMap);
        int startAngle = (int) robot.GetGyroAngle();
        telemetry.addData("finish","wating to start");
        telemetry.update();
        System.out.println("init");
        
        waitForStart();
        time.reset();
        robot.setDriveMotorsPower(1, Hardware.DRIVE_MOTOR_TYPES.LEFT);
        robot.setDriveMotorsPower(0, Hardware.DRIVE_MOTOR_TYPES.RIGHT);
        sleep(100);
        int MAXrotations = 3;
        while (rotations < MAXrotations -1 && opModeIsActive()){
            int currentAngle = (int) robot.GetGyroAngle();
            if(currentAngle + 2 > startAngle && currentAngle - 2 < startAngle){
                rotations++;
                sleep(100);

            }
            telemetry.addData("rotations - ",rotations);
            telemetry.update();
        }
        timeToRotate = (time.seconds() - MAXrotations /1000)/ MAXrotations;


        time.reset();

        robot.setDriveMotorsPower(1, Hardware.DRIVE_MOTOR_TYPES.LEFT);
        robot.setDriveMotorsPower(1, Hardware.DRIVE_MOTOR_TYPES.RIGHT);

        int MAXdistance = 100;
        while (traveld < MAXdistance && opModeIsActive()){
            traveld = bot.getPoint().y;
            int timesTraveld = 0;
            telemetry.addData("timesTraveld - ", timesTraveld);
            telemetry.update();
        }
        int distance = 10;
        timeToDrive = (time.seconds())/ (double) (MAXdistance / distance);


        while (opModeIsActive()){
            telemetry.addData("time to rotate - ",timeToRotate);
            telemetry.addData("time to Drive - ",timeToDrive);
            telemetry.update();

            System.out.println("time to rotate - " + timeToRotate);
            System.out.println("time to Drive - " + timeToDrive);
        }

    }
}
