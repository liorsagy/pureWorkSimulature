package teamcode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class MathFunctions {
    /**
     *
     * @param angle
     * @return
     */
    public static double AngleWrap(double angle){
        while(angle < - Math.PI){
            angle+= 2 * Math.PI;
        }
        while(angle > Math.PI){
            angle-= 2* Math.PI;
        }
        return angle;
    }

    /**
     *
     * @param a
     * @param b
     * @return
     */
    public static double dist2D(Point a,Point b){
        return (((b.x - a.x) + (b.y - a.y))/Math.abs((b.x - a.x) + ((b.y - a.y)))) * Math. sqrt((b.x-a.x)*(b.x-a.x) + (b.y-a.y)*(b.y-a.y));
    }

    public static double range(double v,double ma,double mi){
        while(v > ma){
            v = ma;
        }
        while (v < mi){
            v = mi;
        }
        return v;

    }

    /**
     *
     * @param angle
     * @param offset
     * @return
     */
    public static double RotateAngle(double angle,double offset){
        double newAngle = angle + offset;

        if(newAngle > 180){
            newAngle-=360;
        }else if(newAngle < -180){
            newAngle+=360;
        }
        return newAngle;
    }
    /**
     *
     * @param center
     * @param radius
     * @param pointA
     * @param pointB
     * @return
     */
    public static ArrayList<Point> getCircleLineIntersectionPoint(Point center, double radius,
                                                             Point pointA, Point pointB) {
        ArrayList<Point> list = new ArrayList<Point>();
        double baX = pointB.x - pointA.x;
        double baY = pointB.y - pointA.y;
        double caX = center.x - pointA.x;
        double caY = center.y - pointA.y;

        double a = baX * baX + baY * baY;
        double bBy2 = baX * caX + baY * caY;
        double c = caX * caX + caY * caY - radius * radius;

        double pBy2 = bBy2 / a;
        double q = c / a;

        double disc = pBy2 * pBy2 - q;
        if (disc < 0) {
            return list;
        }
        // if disc == 0 ... dealt with later
        double tmpSqrt = Math.sqrt(disc);
        double abScalingFactor1 = -pBy2 + tmpSqrt;
        double abScalingFactor2 = -pBy2 - tmpSqrt;

        Point p1 = new Point(pointA.x - baX * abScalingFactor1, pointA.y
                - baY * abScalingFactor1);
        list.add(p1);
        if (disc == 0) { // abScalingFactor1 == abScalingFactor2
            return list;
        }
        Point p2 = new Point(pointA.x - baX * abScalingFactor2, pointA.y
                - baY * abScalingFactor2);
        list.add(p2);
        return list;
    }
}
