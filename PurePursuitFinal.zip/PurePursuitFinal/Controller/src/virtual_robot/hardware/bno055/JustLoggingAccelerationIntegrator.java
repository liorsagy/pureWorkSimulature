package virtual_robot.hardware.bno055;

/*
Dummy class
 */

public class JustLoggingAccelerationIntegrator implements BNO055IMU.AccelerationIntegrator {
}
