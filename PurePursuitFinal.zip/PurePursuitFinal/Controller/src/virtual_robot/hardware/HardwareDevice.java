package virtual_robot.hardware;

public interface HardwareDevice {
}
