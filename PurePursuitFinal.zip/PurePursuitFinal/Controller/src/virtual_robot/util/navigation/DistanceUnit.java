package virtual_robot.util.navigation;

public enum DistanceUnit {
    METER, CM, MM, INCH
}
